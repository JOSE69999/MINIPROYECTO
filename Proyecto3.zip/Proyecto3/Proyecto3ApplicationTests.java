package com.Calculadora2.Proyecto3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
